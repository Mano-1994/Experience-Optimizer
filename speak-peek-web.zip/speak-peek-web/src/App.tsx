import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Box, CssBaseline, Toolbar } from "@mui/material";
import { Provider } from "react-redux";
import { store } from "./store";
import SidebarWithDropdown from "./components/Common/SidebarWithDropdown";
import Header from "./components/Common/Header";
import Dashboard from "./components/Dashboard/Dashboard";
import CompanyTable from "./components/Company/CompanyTable";
import BusinessUnitTable from "./components/BusinessUnit/BusinessUnitTable";
import AuthorizationTable from "./components/Authorization/AuthorizationTable";
import BotTable from "./components/Bot/BotTable";
import AddBot from "./components/Bot/AddBot";
import BotIntents from "./components/Bot/BotIntents";
import Login from "./components/Auth/Login";

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <Box sx={{ display: "flex" }}>
    <CssBaseline />
    <Header />
    <SidebarWithDropdown />
    <Box
      component="main"
      sx={{
        flexGrow: 1,
        p: 3,
        transition: "margin 0.3s ease-in-out",
      }}
    >
      <Toolbar />
      {children}
    </Box>
  </Box>
);

const App: React.FC = () => {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <MainLayout>
                <Dashboard />
              </MainLayout>
            }
          />
          <Route
            path="/companies"
            element={
              <MainLayout>
                <CompanyTable />
              </MainLayout>
            }
          />
          <Route
            path="/business-units"
            element={
              <MainLayout>
                <BusinessUnitTable />
              </MainLayout>
            }
          />
          <Route
            path="/authorizations"
            element={
              <MainLayout>
                <AuthorizationTable />
              </MainLayout>
            }
          />
          <Route
            path="/settings"
            element={
              <MainLayout>
                <div>Settings</div>
              </MainLayout>
            }
          />
          <Route
            path="/bots"
            element={
              <MainLayout>
                <BotTable />
              </MainLayout>
            }
          />
          <Route
            path="/bots/add"
            element={
              <MainLayout>
                <AddBot />
              </MainLayout>
            }
          />
          <Route
            path="/bots/:id/intents"
            element={
              <MainLayout>
                <BotIntents />
              </MainLayout>
            }
          />
        </Routes>
      </Router>
    </Provider>
  );
};

export default App;
