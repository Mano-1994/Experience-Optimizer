import React from "react";
import {
  Box,
  Container,
  Paper,
  Typography,
  Button,
  TextField,
  useTheme,
  Divider,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Login: React.FC = () => {
  const theme = useTheme();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/");
  };

  const handleGenesysLogin = () => {
    window.location.href = "http://localhost:8000/auth/genesys";
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: theme.palette.grey[100],
      }}
    >
      <Container maxWidth="sm">
        <Paper
          elevation={3}
          sx={{
            padding: 4,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 3,
          }}
        >
          <Typography variant="h4" component="h1" gutterBottom>
            Experience Optimizer
          </Typography>
          <Typography variant="body1" color="text.secondary" align="center">
            Sign in to your account
          </Typography>

          <Button
            fullWidth
            variant="contained"
            size="large"
            onClick={handleGenesysLogin}
            sx={{
              backgroundColor: "#FF4F1F",
              "&:hover": {
                backgroundColor: "#E64012",
              },
            }}
          >
            Sign in with Genesys
          </Button>

          <Box
            sx={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              gap: 2,
            }}
          >
            <Divider sx={{ flexGrow: 1 }} />
            <Typography variant="body2" color="text.secondary">
              or
            </Typography>
            <Divider sx={{ flexGrow: 1 }} />
          </Box>

          <Box
            component="form"
            onSubmit={handleLogin}
            sx={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              gap: 2,
            }}
          >
            <TextField
              required
              fullWidth
              label="Email"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <TextField
              required
              fullWidth
              label="Password"
              name="password"
              type="password"
              autoComplete="current-password"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              sx={{ mt: 1 }}
            >
              Sign In
            </Button>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Login;
