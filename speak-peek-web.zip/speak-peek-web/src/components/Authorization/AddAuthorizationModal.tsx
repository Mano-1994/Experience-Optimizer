import React, { useState } from "react";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

interface AddAuthorizationModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (authorization: any) => void;
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const AddAuthorizationModal: React.FC<AddAuthorizationModalProps> = ({
  open,
  onClose,
  onAdd,
}) => {
  const [company, setCompany] = useState("");
  const [name, setName] = useState("");
  const [clientId, setClientId] = useState("");
  const [region, setRegion] = useState("");
  const currentUser = useSelector((state: RootState) => state.user);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      company,
      name,
      clientId,
      region,
      lastUpdateBy: currentUser.name,
      lastUpdateDate: new Date().toISOString().split("T")[0],
    });
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" component="h2" mb={2}>
          Add New Authorization
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Client ID"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Region"
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            margin="normal"
            required
          />
          <Box mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Add Authorization
            </Button>
            <Button onClick={onClose} variant="outlined" sx={{ ml: 1 }}>
              Cancel
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

export default AddAuthorizationModal;
