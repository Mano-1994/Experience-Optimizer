import React, { useState, useEffect } from "react";
import {
  Modal,
  Box,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

interface EditAuthorizationModalProps {
  open: boolean;
  onClose: () => void;
  onEdit: (authorization: any) => void;
  authorization: any;
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const EditAuthorizationModal: React.FC<EditAuthorizationModalProps> = ({
  open,
  onClose,
  onEdit,
  authorization,
}) => {
  const [name, setName] = useState(authorization?.name || "");
  const [description, setDescription] = useState(
    authorization?.description || ""
  );
  const [type, setType] = useState(authorization?.type || "");
  const [scope, setScope] = useState(authorization?.scope || "");
  const currentUser = useSelector((state: RootState) => state.user);

  useEffect(() => {
    if (authorization) {
      setName(authorization.name || "");
      setDescription(authorization.description || "");
      setType(authorization.type || "");
      setScope(authorization.scope || "");
    }
  }, [authorization]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEdit({
      ...authorization,
      name,
      description,
      type,
      scope,
      lastUpdateBy: currentUser.name,
      lastUpdateDate: new Date().toISOString().split("T")[0],
    });
    onClose();
  };

  if (!authorization) {
    return null;
  }

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" component="h2" mb={2}>
          Edit Authorization
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            margin="normal"
            required
          />
          <FormControl fullWidth margin="normal" required>
            <InputLabel>Type</InputLabel>
            <Select
              value={type}
              label="Type"
              onChange={(e) => setType(e.target.value)}
            >
              <MenuItem value="Role">Role</MenuItem>
              <MenuItem value="Permission">Permission</MenuItem>
            </Select>
          </FormControl>
          <TextField
            fullWidth
            label="Scope"
            value={scope}
            onChange={(e) => setScope(e.target.value)}
            margin="normal"
            required
          />
          <Box mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Save Changes
            </Button>
            <Button onClick={onClose} variant="outlined" sx={{ ml: 1 }}>
              Cancel
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

export default EditAuthorizationModal;
