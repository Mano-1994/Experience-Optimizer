import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  TextField,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  RadioGroup,
  FormControlLabel,
  Radio,
  Paper,
  LinearProgress,
} from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { styled } from "@mui/material/styles";
import {
  initialCompanies,
  initialBusinessUnits,
  Bot,
  addNewBot,
  initialBots,
} from "../../utils/tempData";
import { green } from "@mui/material/colors";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { Alert, Snackbar } from "@mui/material";

interface FileUploadProgress {
  progress: number;
  fileName: string;
  size: number;
}

interface DateRange {
  startDate: Date | null;
  endDate: Date | null;
}

const VisuallyHiddenInput = styled("input")({
  clip: "rect(0 0 0 0)",
  clipPath: "inset(50%)",
  height: 1,
  overflow: "hidden",
  position: "absolute",
  bottom: 0,
  left: 0,
  whiteSpace: "nowrap",
  width: 1,
});

const AddBot: React.FC = () => {
  const [botName, setBotName] = useState("");
  const [selectedCompany, setSelectedCompany] = useState("");
  const [selectedBusinessUnit, setSelectedBusinessUnit] = useState("");
  const [inputType, setInputType] = useState("audio");
  const [audioFiles, setAudioFiles] = useState<FileUploadProgress[]>([]);
  const [textFiles, setTextFiles] = useState<FileUploadProgress[]>([]);
  const [dataSource, setDataSource] = useState("local");
  const [dateRange, setDateRange] = useState<DateRange>({
    startDate: null,
    endDate: null,
  });
  const navigate = useNavigate();
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasTargetFile, setHasTargetFile] = useState(false);

  useEffect(() => {
    if (dataSource === "local") {
      const hasFiles =
        inputType === "audio" ? audioFiles.length > 0 : textFiles.length > 0;
      setHasTargetFile(hasFiles);
    } else {
      setHasTargetFile(true);
    }
  }, [dataSource, inputType, audioFiles, textFiles]);

  const simulateUpload = (file: File, isAudio: boolean) => {
    const newFile: FileUploadProgress = {
      fileName: file.name,
      size: file.size,
      progress: 0,
    };

    if (isAudio) {
      setAudioFiles((prev) => [...prev, newFile]);
    } else {
      setTextFiles((prev) => [...prev, newFile]);
    }

    const intervalTime = Math.random() * (1000 - 200) + 200; // Random interval between 200ms and 1000ms
    const progressIncrement = Math.random() * (15 - 5) + 5; // Random increment between 5 and 15

    const interval = setInterval(() => {
      if (isAudio) {
        setAudioFiles((prev) =>
          prev.map((f) =>
            f.fileName === file.name
              ? {
                  ...f,
                  progress: Math.min(f.progress + progressIncrement, 100),
                }
              : f
          )
        );
      } else {
        setTextFiles((prev) =>
          prev.map((f) =>
            f.fileName === file.name
              ? {
                  ...f,
                  progress: Math.min(f.progress + progressIncrement, 100),
                }
              : f
          )
        );
      }
    }, intervalTime);

    // Cleanup interval when progress reaches 100%
    const checkCompletion = setInterval(() => {
      if (isAudio) {
        const uploadedFile = audioFiles.find((f) => f.fileName === file.name);
        if (uploadedFile?.progress === 100) {
          clearInterval(interval);
          clearInterval(checkCompletion);
        }
      } else {
        const uploadedFile = textFiles.find((f) => f.fileName === file.name);
        if (uploadedFile?.progress === 100) {
          clearInterval(interval);
          clearInterval(checkCompletion);
        }
      }
    }, 100);
  };

  const handleAudioUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        simulateUpload(file, true);
      });
    }
  };

  const handleTextUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        simulateUpload(file, false);
      });
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const handleCreateBot = () => {
    setIsProcessing(true);

    const companyName =
      initialCompanies.find((company) => company.id === Number(selectedCompany))
        ?.companyName || "";

    const businessUnitName =
      initialBusinessUnits.find((bu) => bu.id === Number(selectedBusinessUnit))
        ?.name || "";

    // Format the date in YYYY-MM-DD format
    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().split("T")[0]; // This will give YYYY-MM-DD

    const newBot: Bot = {
      id: initialBots.length + 1,
      name: botName,
      company: companyName,
      businessUnit: businessUnitName,
      status: "In Progress",
      lastUpdateBy: "System",
      lastUpdateDate: formattedDate, // Using the new date format
      intents: [],
    };

    // Add the bot to tempData
    addNewBot(newBot);

    // Navigate back to the bots list with the new bot data
    navigate("/bots", { state: { newBot } });
  };

  const areUploadsComplete = () => {
    if (dataSource === "local") {
      if (inputType === "audio") {
        return (
          audioFiles.length > 0 &&
          audioFiles.every((file) => file.progress === 100)
        );
      }
      if (inputType === "text") {
        return (
          textFiles.length > 0 &&
          textFiles.every((file) => file.progress === 100)
        );
      }
    }
    return true;
  };

  const handleSubmit = (botData: any) => {
    // ... your existing submit logic ...

    // Assuming you have the new bot data with an ID
    const newBot = {
      id: initialBots.length + 1,
      ...botData,
      status: "Active",
      lastUpdateBy: "Current User",
      lastUpdateDate: new Date().toISOString(),
    };

    navigate("/bots", { state: { newBot } });
  };

  return (
    <Box sx={{ maxWidth: 800, margin: "0 auto", p: 2 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Add New Bot
      </Typography>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box
          component="form"
          sx={{ display: "flex", flexDirection: "column", gap: 2 }}
        >
          <TextField
            label="Bot Name"
            value={botName}
            onChange={(e) => setBotName(e.target.value)}
            fullWidth
            required
          />

          <FormControl fullWidth required>
            <InputLabel>Company</InputLabel>
            <Select
              value={selectedCompany}
              label="Company"
              onChange={(e) => setSelectedCompany(e.target.value)}
            >
              {initialCompanies.map((company) => (
                <MenuItem key={company.id} value={company.id}>
                  {company.companyName}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth required>
            <InputLabel>Business Unit</InputLabel>
            <Select
              value={selectedBusinessUnit}
              label="Business Unit"
              onChange={(e) => setSelectedBusinessUnit(e.target.value)}
            >
              {initialBusinessUnits.map((bu) => (
                <MenuItem key={bu.id} value={bu.id}>
                  {bu.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth required>
            <InputLabel>Data Source</InputLabel>
            <Select
              value={dataSource}
              label="Data Source"
              onChange={(e) => setDataSource(e.target.value)}
            >
              <MenuItem value="genesys">Fetch from Genesys</MenuItem>
              <MenuItem value="local">Upload Local Files</MenuItem>
            </Select>
          </FormControl>

          {dataSource === "local" && (
            <>
              <FormControl fullWidth required>
                <InputLabel>Input Type</InputLabel>
                <Select
                  value={inputType}
                  label="Input Type"
                  onChange={(e) => setInputType(e.target.value)}
                >
                  <MenuItem value="audio">Audio</MenuItem>
                  <MenuItem value="text">Text</MenuItem>
                </Select>
              </FormControl>

              {inputType === "audio" && (
                <Box>
                  <Button
                    component="label"
                    variant="contained"
                    startIcon={<CloudUploadIcon />}
                  >
                    Upload Files
                    <VisuallyHiddenInput
                      type="file"
                      accept="audio/*,.opus,.ogg"
                      multiple
                      onChange={handleAudioUpload}
                    />
                  </Button>
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ mt: 1, display: "block" }}
                  >
                    Accepted file types: MP3, WAV, M4A, OPUS, OGG
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    {audioFiles.map((file, index) => (
                      <Box key={index} sx={{ mb: 2 }}>
                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            mb: 1,
                          }}
                        >
                          <Typography variant="body2">
                            {file.fileName}
                          </Typography>
                          <Typography variant="body2">
                            {formatFileSize(file.size)}
                          </Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={file.progress}
                          sx={{
                            height: 8,
                            borderRadius: 2,
                            bgcolor: "grey.200",
                            "& .MuiLinearProgress-bar": {
                              bgcolor:
                                file.progress === 100
                                  ? green[500]
                                  : "primary.main",
                            },
                          }}
                        />
                      </Box>
                    ))}
                  </Box>
                </Box>
              )}

              {inputType === "text" && (
                <Box>
                  <Box sx={{ display: "flex", gap: 2 }}>
                    <Button
                      component="label"
                      variant="contained"
                      startIcon={<CloudUploadIcon />}
                    >
                      Upload Files
                      <VisuallyHiddenInput
                        type="file"
                        accept=".txt,.srt,.vtt,.csv,.json"
                        multiple
                        onChange={handleTextUpload}
                      />
                    </Button>
                  </Box>
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ mt: 1, display: "block" }}
                  >
                    Accepted file types: TXT, SRT, VTT, CSV, JSON
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    {textFiles.map((file, index) => (
                      <Box key={index} sx={{ mb: 2 }}>
                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            mb: 1,
                          }}
                        >
                          <Typography variant="body2">
                            {file.fileName}
                          </Typography>
                          <Typography variant="body2">
                            {formatFileSize(file.size)}
                          </Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={file.progress}
                          sx={{
                            height: 8,
                            borderRadius: 2,
                            bgcolor: "grey.200",
                            "& .MuiLinearProgress-bar": {
                              bgcolor:
                                file.progress === 100
                                  ? green[500]
                                  : "primary.main",
                            },
                          }}
                        />
                      </Box>
                    ))}
                  </Box>
                </Box>
              )}
            </>
          )}

          {dataSource === "genesys" && (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <Box sx={{ display: "flex", gap: 2 }}>
                  <DatePicker
                    label="Start Date"
                    value={dateRange.startDate}
                    onChange={(newValue) => {
                      setDateRange((prev) => ({
                        ...prev,
                        startDate: newValue,
                      }));
                    }}
                    sx={{ flex: 1 }}
                    maxDate={dateRange.endDate || undefined}
                  />
                  <DatePicker
                    label="End Date"
                    value={dateRange.endDate}
                    onChange={(newValue) => {
                      setDateRange((prev) => ({
                        ...prev,
                        endDate: newValue,
                      }));
                    }}
                    sx={{ flex: 1 }}
                    minDate={dateRange.startDate || undefined}
                  />
                </Box>
              </LocalizationProvider>
              <Box sx={{ p: 2, bgcolor: "grey.100", borderRadius: 1 }}>
                <Typography variant="body1" color="text.secondary">
                  {dateRange.startDate && dateRange.endDate ? (
                    <>
                      Audio files will be fetched from Genesys for the period:
                      <br />
                      {format(dateRange.startDate, "MMM dd, yyyy")} -{" "}
                      {format(dateRange.endDate, "MMM dd, yyyy")}
                    </>
                  ) : (
                    "Please select a date range to fetch audio files from Genesys"
                  )}
                </Typography>
              </Box>
            </Box>
          )}

          <Button
            variant="contained"
            color="primary"
            size="large"
            sx={{ mt: 2 }}
            disabled={
              !botName ||
              !selectedCompany ||
              !selectedBusinessUnit ||
              (dataSource === "genesys" &&
                (!dateRange.startDate || !dateRange.endDate)) ||
              (dataSource === "local" && !hasTargetFile) ||
              !areUploadsComplete() ||
              isProcessing
            }
            onClick={handleCreateBot}
          >
            {isProcessing ? "Creating Bot..." : "Create Bot"}
          </Button>
        </Box>
      </Paper>
      <Snackbar
        open={showSuccessToast}
        autoHideDuration={6000}
        onClose={() => setShowSuccessToast(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert severity="success" sx={{ width: "100%" }}>
          Bot creation completed successfully!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AddBot;
