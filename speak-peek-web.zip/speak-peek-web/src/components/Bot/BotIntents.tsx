import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  Box,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ListItemButton,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import { initialBots, Intent, Bot } from "../../utils/tempData";

const BotIntents: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [bot, setBot] = useState<Bot | null>(null);
  const [intents, setIntents] = useState<Intent[]>([]);
  const [selectedIntent, setSelectedIntent] = useState<Intent | null>(null);
  const [isAddingIntent, setIsAddingIntent] = useState(false);
  const [isAddingUtterance, setIsAddingUtterance] = useState(false);
  const [newIntentName, setNewIntentName] = useState("");
  const [newUtterance, setNewUtterance] = useState("");

  useEffect(() => {
    const foundBot = initialBots.find((b) => b.id === Number(id));
    if (foundBot) {
      const botWithIntents: Bot = {
        ...foundBot,
        intents: foundBot.intents || [],
      };
      setBot(botWithIntents);
      setIntents(botWithIntents.intents);
    } else {
      setBot(null);
      setIntents([]);
    }
  }, [id]);

  const handleIntentClick = (intent: Intent) => {
    setSelectedIntent(intent);
  };

  const handleAddIntent = () => {
    if (newIntentName.trim()) {
      const newIntent: Intent = {
        id: intents.length + 1,
        name: newIntentName.trim(),
        utterances: [],
      };
      setIntents([...intents, newIntent]);
      setNewIntentName("");
      setIsAddingIntent(false);
    }
  };

  const handleEditIntent = (id: number, newName: string) => {
    setIntents(
      intents.map((intent) =>
        intent.id === id ? { ...intent, name: newName } : intent
      )
    );
    if (selectedIntent && selectedIntent.id === id) {
      setSelectedIntent({ ...selectedIntent, name: newName });
    }
  };

  const handleDeleteIntent = (id: number) => {
    setIntents(intents.filter((intent) => intent.id !== id));
    if (selectedIntent && selectedIntent.id === id) {
      setSelectedIntent(null);
    }
  };

  const handleAddUtterance = () => {
    if (selectedIntent && newUtterance.trim()) {
      const updatedIntent = {
        ...selectedIntent,
        utterances: [...selectedIntent.utterances, newUtterance.trim()],
      };
      setIntents(
        intents.map((intent) =>
          intent.id === selectedIntent.id ? updatedIntent : intent
        )
      );
      setSelectedIntent(updatedIntent);
      setNewUtterance("");
      setIsAddingUtterance(false);
    }
  };

  const handleEditUtterance = (index: number, newText: string) => {
    if (selectedIntent) {
      const updatedUtterances = [...selectedIntent.utterances];
      updatedUtterances[index] = newText;
      const updatedIntent = {
        ...selectedIntent,
        utterances: updatedUtterances,
      };
      setIntents(
        intents.map((intent) =>
          intent.id === selectedIntent.id ? updatedIntent : intent
        )
      );
      setSelectedIntent(updatedIntent);
    }
  };

  const handleDeleteUtterance = (index: number) => {
    if (selectedIntent) {
      const updatedUtterances = selectedIntent.utterances.filter(
        (_, i) => i !== index
      );
      const updatedIntent = {
        ...selectedIntent,
        utterances: updatedUtterances,
      };
      setIntents(
        intents.map((intent) =>
          intent.id === selectedIntent.id ? updatedIntent : intent
        )
      );
      setSelectedIntent(updatedIntent);
    }
  };

  return (
    <Box display="flex" height="100%" flexDirection="column">
      <Typography variant="h4" component="h1" gutterBottom>
        Intents for {bot?.name}
      </Typography>
      <Box display="flex" flexGrow={1}>
        <Box width="30%" borderRight={1} borderColor="divider" p={2}>
          <Typography variant="h6">Intents</Typography>
          <List>
            {intents.map((intent) => (
              <ListItemButton
                key={intent.id}
                onClick={() => handleIntentClick(intent)}
                selected={selectedIntent?.id === intent.id}
                component="div"
              >
                <ListItemText primary={intent.name} />
                <IconButton
                  onClick={() =>
                    handleEditIntent(
                      intent.id,
                      prompt("New name:", intent.name) || intent.name
                    )
                  }
                >
                  <EditIcon />
                </IconButton>
                <IconButton onClick={() => handleDeleteIntent(intent.id)}>
                  <DeleteIcon />
                </IconButton>
              </ListItemButton>
            ))}
          </List>
          <Button
            startIcon={<AddIcon />}
            onClick={() => setIsAddingIntent(true)}
          >
            Add Intent
          </Button>
        </Box>
        <Box width="70%" p={2}>
          <Typography variant="h6">Utterances</Typography>
          {selectedIntent && (
            <List>
              {selectedIntent.utterances.map((utterance, index) => (
                <ListItem key={index}>
                  <ListItemText primary={utterance} />
                  <IconButton
                    onClick={() =>
                      handleEditUtterance(
                        index,
                        prompt("New utterance:", utterance) || utterance
                      )
                    }
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDeleteUtterance(index)}>
                    <DeleteIcon />
                  </IconButton>
                </ListItem>
              ))}
            </List>
          )}
          {selectedIntent && (
            <Button
              startIcon={<AddIcon />}
              onClick={() => setIsAddingUtterance(true)}
            >
              Add Utterance
            </Button>
          )}
        </Box>
      </Box>
      <Dialog open={isAddingIntent} onClose={() => setIsAddingIntent(false)}>
        <DialogTitle>Add New Intent</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Intent Name"
            fullWidth
            value={newIntentName}
            onChange={(e) => setNewIntentName(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsAddingIntent(false)}>Cancel</Button>
          <Button onClick={handleAddIntent}>Add</Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={isAddingUtterance}
        onClose={() => setIsAddingUtterance(false)}
      >
        <DialogTitle>Add New Utterance</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Utterance"
            fullWidth
            value={newUtterance}
            onChange={(e) => setNewUtterance(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsAddingUtterance(false)}>Cancel</Button>
          <Button onClick={handleAddUtterance}>Add</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default BotIntents;
