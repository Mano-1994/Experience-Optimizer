import React, { useState, useCallback, useMemo, useEffect } from "react";
import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import {
  IconButton,
  Button,
  Box,
  Typography,
  TextField,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import EditBotModal from "./EditBotModal";
import {
  initialCompanies,
  initialBusinessUnits,
  initialBots,
} from "../../utils/tempData";
import { useNavigate, useLocation } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
const BotTable: React.FC = () => {
  const location = useLocation();
  const [rows, setRows] = useState(initialBots);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingBot, setEditingBot] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCompany, setSelectedCompany] = useState("");
  const [selectedBusinessUnit, setSelectedBusinessUnit] = useState("");
  const navigate = useNavigate();
  const [showProcessingToast, setShowProcessingToast] = useState(false);
  const [showReadyToast, setShowReadyToast] = useState(false);

  useEffect(() => {
    if (location.state?.newBot) {
      const newBot = location.state.newBot;
      setRows((prevRows) => {
        if (!prevRows.some((bot) => bot.id === newBot.id)) {
          return [...prevRows, newBot];
        }
        return prevRows;
      });
      setShowProcessingToast(true);

      const delay = Math.random() * (10000 - 5000) + 5000;

      setTimeout(() => {
        setShowProcessingToast(false);
        setRows((prevRows) =>
          prevRows.map((bot) =>
            bot.id === newBot.id ? { ...bot, status: "Draft" } : bot
          )
        );
        setShowReadyToast(true);
      }, delay);

      window.history.replaceState({}, document.title);
    }
  }, [location.state?.newBot]);

  const handleEditBot = (id: number) => {
    const botToEdit = rows.find((row) => row.id === id);
    if (botToEdit) {
      setEditingBot(botToEdit);
      setIsEditModalOpen(true);
    }
  };

  const handleSaveEdit = (editedBot: any) => {
    setRows(rows.map((row) => (row.id === editedBot.id ? editedBot : row)));
  };

  const handleDeleteBot = (id: number) => {
    setRows(rows.filter((row) => row.id !== id));
  };

  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(event.target.value);
    },
    []
  );

  const filteredRows = useMemo(() => {
    return rows.filter((row) => {
      const matchesSearch = Object.values(row).some(
        (value) =>
          value &&
          value.toString().toLowerCase().includes(searchTerm.toLowerCase())
      );
      const matchesCompany = selectedCompany
        ? row.company === selectedCompany
        : true;
      const matchesBusinessUnit = selectedBusinessUnit
        ? row.businessUnit === selectedBusinessUnit
        : true;
      return matchesSearch && matchesCompany && matchesBusinessUnit;
    });
  }, [rows, searchTerm, selectedCompany, selectedBusinessUnit]);

  const columns: GridColDef[] = [
    { field: "id", headerName: "ID", width: 70, flex: 0.5 },
    {
      field: "name",
      headerName: "Name",
      flex: 1,
      renderCell: (params) => (
        <Button
          component={RouterLink}
          to={`/bots/${params.row.id}/intents`}
          color="primary"
          sx={{
            textTransform: "none",
            textAlign: "left",
            justifyContent: "flex-start",
            "&:hover": {
              textDecoration: "underline",
              background: "transparent",
            },
          }}
        >
          {params.value}
        </Button>
      ),
    },
    { field: "company", headerName: "Company", flex: 1, minWidth: 150 },
    {
      field: "businessUnit",
      headerName: "Business Unit",
      flex: 1,
      minWidth: 120,
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 120,
      renderCell: (params: GridRenderCellParams) => (
        <Box sx={{ display: "flex", alignItems: "center" }}>
          {params.value}
          {params.value === "In Progress" && (
            <CircularProgress size={20} sx={{ ml: 1 }} />
          )}
        </Box>
      ),
    },
    {
      field: "lastUpdateBy",
      headerName: "Last Update By",
      flex: 1,
      minWidth: 150,
    },
    {
      field: "lastUpdateDate",
      headerName: "Last Update Date",
      flex: 1,
      minWidth: 150,
    },
    {
      field: "actions",
      headerName: "Actions",
      width: 120,
      flex: 0.5,
      renderCell: (params: GridRenderCellParams) => (
        <>
          <IconButton onClick={() => handleEditBot(params.row.id)}>
            <EditIcon />
          </IconButton>
          <IconButton onClick={() => handleDeleteBot(params.row.id)}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  const selectStyles = {
    select: {
      display: "flex",
      alignItems: "center",
      height: "40px", // Adjust this value as needed
    },
  };

  return (
    <Box sx={{ width: "100%", display: "flex", flexDirection: "column" }}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
        flexWrap="wrap"
      >
        <Box display="flex" alignItems="center" flexWrap="wrap">
          <Typography variant="h4" component="h1" sx={{ mr: 2, mb: 1 }}>
            Bots
          </Typography>
          <FormControl sx={{ minWidth: 200, mr: 2, mb: 1 }}>
            <InputLabel>Company</InputLabel>
            <Select
              value={selectedCompany}
              label="Company"
              onChange={(e) => setSelectedCompany(e.target.value)}
              size="small"
              sx={selectStyles}
            >
              <MenuItem value="">All</MenuItem>
              {initialCompanies.map((company) => (
                <MenuItem key={company.id} value={company.companyName}>
                  {company.companyName}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl sx={{ minWidth: 200, mb: 1 }}>
            <InputLabel>Business Unit</InputLabel>
            <Select
              value={selectedBusinessUnit}
              label="Business Unit"
              onChange={(e) => setSelectedBusinessUnit(e.target.value)}
              size="small"
              sx={selectStyles}
            >
              <MenuItem value="">All</MenuItem>
              {initialBusinessUnits.map((bu) => (
                <MenuItem key={bu.id} value={bu.name}>
                  {bu.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>
        <Box display="flex" alignItems="center" flexWrap="wrap">
          <TextField
            variant="outlined"
            size="small"
            placeholder="Search bots"
            value={searchTerm}
            onChange={handleSearch}
            InputProps={{
              startAdornment: <SearchIcon color="action" />,
            }}
            sx={{ mr: 2, mb: 1, minWidth: 200 }}
          />
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => navigate("/bots/add")}
            sx={{ mb: 1 }}
          >
            Add Bot
          </Button>
        </Box>
      </Box>
      <Box sx={{ flexGrow: 1, width: "100%", overflow: "hidden" }}>
        <DataGrid
          rows={filteredRows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 10 },
            },
          }}
          pageSizeOptions={[5, 10, 25]}
          disableRowSelectionOnClick
          autoHeight
          sx={{
            "& .MuiDataGrid-root": {
              width: "100%",
              maxWidth: "100%",
              overflowX: "hidden",
            },
            "& .MuiDataGrid-cell": {
              whiteSpace: "normal",
              wordWrap: "break-word",
            },
          }}
        />
      </Box>
      {editingBot && (
        <EditBotModal
          open={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setEditingBot(null);
          }}
          onEdit={handleSaveEdit}
          bot={editingBot}
        />
      )}
      <Snackbar
        open={showProcessingToast}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert severity="info" sx={{ width: "100%" }}>
          Bot is being processed...
        </Alert>
      </Snackbar>

      <Snackbar
        open={showReadyToast}
        autoHideDuration={6000}
        onClose={() => setShowReadyToast(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert severity="success" sx={{ width: "100%" }}>
          Bot is ready to be reviewed!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default BotTable;
