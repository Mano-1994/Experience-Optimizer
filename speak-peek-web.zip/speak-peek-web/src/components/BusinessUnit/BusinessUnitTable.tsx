import React, { useState, useCallback } from "react";
import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import { IconButton, Button, Box, Typography, TextField } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import AddBusinessUnitModal from "./AddBusinessUnitModal";
import EditBusinessUnitModal from "./EditBusinessUnitModal";
import { initialBusinessUnits } from "../../utils/tempData";

const BusinessUnitTable: React.FC = () => {
  const [rows, setRows] = useState(initialBusinessUnits);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingBusinessUnit, setEditingBusinessUnit] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const handleAddBusinessUnit = (newBusinessUnit: any) => {
    const newId = Math.max(...rows.map((row) => row.id)) + 1;
    setRows([...rows, { ...newBusinessUnit, id: newId }]);
  };

  const handleEditBusinessUnit = (id: number) => {
    const businessUnitToEdit = rows.find((row) => row.id === id);
    if (businessUnitToEdit) {
      setEditingBusinessUnit(businessUnitToEdit);
      setIsEditModalOpen(true);
    }
  };

  const handleSaveEdit = (editedBusinessUnit: any) => {
    setRows(
      rows.map((row) =>
        row.id === editedBusinessUnit.id ? editedBusinessUnit : row
      )
    );
  };

  const handleDeleteBusinessUnit = (id: number) => {
    setRows(rows.filter((row) => row.id !== id));
  };

  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(event.target.value);
    },
    []
  );

  const filteredRows = rows.filter((row) =>
    Object.values(row).some(
      (value) =>
        value &&
        value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const columns: GridColDef[] = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "name", headerName: "Name", flex: 1 },
    { field: "company", headerName: "Company", flex: 1 },
    {
      field: "agentEntity",
      headerName: "Agent Entity",
      flex: 1,
    },
    { field: "divisionName", headerName: "Division Name", flex: 1 },
    {
      field: "authorizationClient",
      headerName: "Auth Client",
      flex: 1,
    },
    { field: "timezone", headerName: "Timezone", flex: 1 },
    { field: "lastUpdateBy", headerName: "Last Update By", flex: 1 },
    { field: "lastUpdateDate", headerName: "Last Update Date", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      flex: 0.8,
      renderCell: (params: GridRenderCellParams) => (
        <>
          <IconButton onClick={() => handleEditBusinessUnit(params.row.id)}>
            <EditIcon />
          </IconButton>
          <IconButton onClick={() => handleDeleteBusinessUnit(params.row.id)}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <div
      style={{
        // height: "calc(100vh - 64px)",
        width: "100%",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <Typography variant="h4" component="h1">
          Business Units
        </Typography>
        <Box display="flex" alignItems="center">
          <TextField
            variant="outlined"
            size="small"
            placeholder="Search business units"
            value={searchTerm}
            onChange={handleSearch}
            InputProps={{
              startAdornment: <SearchIcon color="action" />,
            }}
            sx={{ mr: 2 }}
          />
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => setIsAddModalOpen(true)}
          >
            Add Business Unit
          </Button>
        </Box>
      </Box>
      <DataGrid
        rows={filteredRows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        pageSizeOptions={[5, 10, 25]}
        disableRowSelectionOnClick
        autoHeight
      />
      <AddBusinessUnitModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddBusinessUnit}
      />
      {editingBusinessUnit && (
        <EditBusinessUnitModal
          open={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setEditingBusinessUnit(null);
          }}
          onEdit={handleSaveEdit}
          businessUnit={editingBusinessUnit}
        />
      )}
    </div>
  );
};

export default BusinessUnitTable;
