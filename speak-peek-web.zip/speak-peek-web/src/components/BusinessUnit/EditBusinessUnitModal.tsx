import React, { useState, useEffect } from "react";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

interface EditBusinessUnitModalProps {
  open: boolean;
  onClose: () => void;
  onEdit: (businessUnit: any) => void;
  businessUnit: any;
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const EditBusinessUnitModal: React.FC<EditBusinessUnitModalProps> = ({
  open,
  onClose,
  onEdit,
  businessUnit,
}) => {
  const [name, setName] = useState(businessUnit?.name || "");
  const [description, setDescription] = useState(
    businessUnit?.description || ""
  );
  const [company, setCompany] = useState(businessUnit?.company || "");
  const [agentEntityKvpName, setAgentEntityKvpName] = useState(
    businessUnit?.agentEntityKvpName || ""
  );
  const [divisionName, setDivisionName] = useState(
    businessUnit?.divisionName || ""
  );
  const [authorizationClient, setAuthorizationClient] = useState(
    businessUnit?.authorizationClient || ""
  );
  const [timezone, setTimezone] = useState(businessUnit?.timezone || "");
  const currentUser = useSelector((state: RootState) => state.user);

  useEffect(() => {
    if (businessUnit) {
      setName(businessUnit.name || "");
      setDescription(businessUnit.description || "");
      setCompany(businessUnit.company || "");
      setAgentEntityKvpName(businessUnit.agentEntityKvpName || "");
      setDivisionName(businessUnit.divisionName || "");
      setAuthorizationClient(businessUnit.authorizationClient || "");
      setTimezone(businessUnit.timezone || "");
    }
  }, [businessUnit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEdit({
      ...businessUnit,
      name,
      description,
      company,
      agentEntityKvpName,
      divisionName,
      authorizationClient,
      timezone,
      lastUpdateBy: currentUser.name,
      lastUpdateDate: new Date().toISOString().split("T")[0],
    });
    onClose();
  };

  if (!businessUnit) {
    return null;
  }

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" component="h2" mb={2}>
          Edit Business Unit
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Agent Entity KVP Name"
            value={agentEntityKvpName}
            onChange={(e) => setAgentEntityKvpName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Division Name"
            value={divisionName}
            onChange={(e) => setDivisionName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Authorization Client"
            value={authorizationClient}
            onChange={(e) => setAuthorizationClient(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Timezone"
            value={timezone}
            onChange={(e) => setTimezone(e.target.value)}
            margin="normal"
            required
          />
          <Box mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Save Changes
            </Button>
            <Button onClick={onClose} variant="outlined" sx={{ ml: 1 }}>
              Cancel
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

export default EditBusinessUnitModal;
