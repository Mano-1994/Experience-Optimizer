import React, { useState, useEffect } from "react";
import {
  Drawer,
  List,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Divider,
  Collapse,
  Box,
  ListItemButton,
} from "@mui/material";
import DashboardIcon from "@mui/icons-material/Dashboard";
import BusinessIcon from "@mui/icons-material/Business";
import GroupWorkIcon from "@mui/icons-material/GroupWork";
import PeopleIcon from "@mui/icons-material/People";
import SettingsIcon from "@mui/icons-material/Settings";
import SecurityIcon from "@mui/icons-material/Security";
import WorkIcon from "@mui/icons-material/Work";
import BotIcon from "@mui/icons-material/SmartToy";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import { Link, useLocation } from "react-router-dom";

const drawerWidth = 240;

const SidebarWithDropdown: React.FC = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const isBusinessOpsPage = [
    "/companies",
    "/business-units",
    "/authorizations",
  ].includes(location.pathname);

  useEffect(() => {
    setOpen(isBusinessOpsPage);
  }, [isBusinessOpsPage]);

  const handleMouseEnter = () => {
    setOpen(true);
  };

  const handleMouseLeave = () => {
    if (!isBusinessOpsPage) {
      setOpen(false);
    }
  };

  const handleNonSubmenuClick = () => {
    setOpen(false);
  };

  const menuItemStyle = {
    "&:hover": {
      backgroundColor: "rgba(0, 0, 0, 0.04)",
    },
    "&.Mui-selected": {
      backgroundColor: "rgba(0, 0, 0, 0.08)",
    },
    paddingLeft: 1,
    paddingRight: 1,
  };

  const menuTextStyle = {
    fontSize: "0.875rem",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  };

  const listItemIconStyle = {
    minWidth: 40,
  };

  return (
    <Drawer
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: drawerWidth,
          boxSizing: "border-box",
        },
      }}
      variant="permanent"
      anchor="left"
    >
      <Toolbar />
      <Divider />
      <List>
        <ListItemButton
          component={Link}
          to="/"
          selected={location.pathname === "/"}
          sx={menuItemStyle}
          onClick={handleNonSubmenuClick}
        >
          <ListItemIcon sx={listItemIconStyle}>
            <DashboardIcon />
          </ListItemIcon>
          <ListItemText
            primary="Dashboard"
            primaryTypographyProps={{ sx: menuTextStyle }}
          />
        </ListItemButton>
        <Box onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          <ListItemButton sx={menuItemStyle}>
            <ListItemIcon sx={listItemIconStyle}>
              <WorkIcon />
            </ListItemIcon>
            <ListItemText
              primary="Business Operations"
              primaryTypographyProps={{ sx: menuTextStyle }}
            />
            {open ? <ExpandLess /> : <ExpandMore />}
          </ListItemButton>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              <ListItemButton
                component={Link}
                to="/companies"
                sx={{ ...menuItemStyle, pl: 4 }}
                selected={location.pathname === "/companies"}
              >
                <ListItemIcon sx={listItemIconStyle}>
                  <BusinessIcon />
                </ListItemIcon>
                <ListItemText
                  primary="Companies"
                  primaryTypographyProps={{ sx: menuTextStyle }}
                />
              </ListItemButton>
              <ListItemButton
                component={Link}
                to="/business-units"
                sx={{ ...menuItemStyle, pl: 4 }}
                selected={location.pathname === "/business-units"}
              >
                <ListItemIcon sx={listItemIconStyle}>
                  <GroupWorkIcon />
                </ListItemIcon>
                <ListItemText
                  primary="Business Units"
                  primaryTypographyProps={{ sx: menuTextStyle }}
                />
              </ListItemButton>
              <ListItemButton
                component={Link}
                to="/authorizations"
                sx={{ ...menuItemStyle, pl: 4 }}
                selected={location.pathname === "/authorizations"}
              >
                <ListItemIcon sx={listItemIconStyle}>
                  <SecurityIcon />
                </ListItemIcon>
                <ListItemText
                  primary="Authorizations"
                  primaryTypographyProps={{ sx: menuTextStyle }}
                />
              </ListItemButton>
            </List>
          </Collapse>
        </Box>
        <ListItemButton
          component={Link}
          to="/bots"
          selected={location.pathname === "/bots"}
          sx={menuItemStyle}
          onClick={handleNonSubmenuClick}
        >
          <ListItemIcon sx={listItemIconStyle}>
            <BotIcon />
          </ListItemIcon>
          <ListItemText
            primary="My Bots"
            primaryTypographyProps={{ sx: menuTextStyle }}
          />
        </ListItemButton>
      </List>
      <Divider />
      <List>
        <ListItemButton
          component={Link}
          to="/settings"
          selected={location.pathname === "/settings"}
          sx={menuItemStyle}
          onClick={handleNonSubmenuClick}
        >
          <ListItemIcon sx={listItemIconStyle}>
            <SettingsIcon />
          </ListItemIcon>
          <ListItemText
            primary="Settings"
            primaryTypographyProps={{ sx: menuTextStyle }}
          />
        </ListItemButton>
      </List>
    </Drawer>
  );
};

export default SidebarWithDropdown;
