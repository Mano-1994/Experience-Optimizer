import React, { useState } from "react";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

interface AddCompanyModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (company: any) => void;
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const AddCompanyModal: React.FC<AddCompanyModalProps> = ({
  open,
  onClose,
  onAdd,
}) => {
  const [companyName, setCompanyName] = useState("");
  const [organizationId, setOrganizationId] = useState("");
  const [authorizationClient, setAuthorizationClient] = useState("");
  const currentUser = useSelector((state: RootState) => state.user);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      companyName,
      organizationId,
      authorizationClient,
      lastUpdateBy: currentUser.name,
      lastUpdateDate: new Date().toISOString().split("T")[0],
    });
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" component="h2" mb={2}>
          Add New Company
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Company Name"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Organization ID"
            value={organizationId}
            onChange={(e) => setOrganizationId(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Authorization Client"
            value={authorizationClient}
            onChange={(e) => setAuthorizationClient(e.target.value)}
            margin="normal"
            required
          />
          <Box mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Add Company
            </Button>
            <Button onClick={onClose} variant="outlined" sx={{ ml: 1 }}>
              Cancel
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

export default AddCompanyModal;
