import React, { useState, useCallback, useEffect } from "react";
import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import { IconButton, Button, Box, Typography, TextField } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import EditCompanyModal from "./EditCompanyModal";
import AddCompanyModal from "./AddCompanyModal";
import { initialCompanies } from "../../utils/tempData";

const CompanyTable: React.FC = () => {
  const [rows, setRows] = useState(initialCompanies);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [pageSize, setPageSize] = useState(5);

  useEffect(() => {
    const calculatePageSize = () => {
      const headerHeight = 52; // Approximate height of the DataGrid header
      const rowHeight = 52; // Default height of a row in DataGrid
      const availableHeight = window.innerHeight - 64 - 120; // Subtracting AppBar height and some padding
      const calculatedPageSize = Math.floor(
        (availableHeight - headerHeight) / rowHeight
      );
      setPageSize(Math.max(1, calculatedPageSize)); // Ensure at least 1 row is shown
    };

    calculatePageSize();
    window.addEventListener("resize", calculatePageSize);

    return () => {
      window.removeEventListener("resize", calculatePageSize);
    };
  }, []);

  const handleAddCompany = (newCompany: any) => {
    const newId = Math.max(...rows.map((row) => row.id)) + 1;
    setRows([...rows, { ...newCompany, id: newId }]);
  };

  const handleEditCompany = (id: number) => {
    const companyToEdit = rows.find((row) => row.id === id);
    if (companyToEdit) {
      setEditingCompany(companyToEdit);
      setIsEditModalOpen(true);
    }
  };

  const handleSaveEdit = (editedCompany: any) => {
    setRows(
      rows.map((row) => (row.id === editedCompany.id ? editedCompany : row))
    );
  };

  const handleDeleteCompany = (id: number) => {
    setRows(rows.filter((row) => row.id !== id));
  };

  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(event.target.value);
    },
    []
  );

  const filteredRows = rows.filter((row) =>
    Object.values(row).some(
      (value) =>
        value &&
        value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const columns: GridColDef[] = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "companyName", headerName: "Company Name", flex: 1.5 },
    { field: "organizationId", headerName: "Organization ID", flex: 1 },
    {
      field: "authorizationClient",
      headerName: "Authorization Client",
      flex: 1,
    },
    { field: "lastUpdateBy", headerName: "Last Update By", flex: 1 },
    { field: "lastUpdateDate", headerName: "Last Update Date", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      flex: 0.8,
      renderCell: (params: GridRenderCellParams) => (
        <>
          <IconButton onClick={() => handleEditCompany(params.row.id)}>
            <EditIcon />
          </IconButton>
          <IconButton onClick={() => handleDeleteCompany(params.row.id)}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <Box
      sx={{
        // height: "calc(100vh - 64px)",
        width: "100%",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <Typography variant="h4" component="h1">
          Companies
        </Typography>
        <Box display="flex" alignItems="center">
          <TextField
            variant="outlined"
            size="small"
            placeholder="Search companies"
            value={searchTerm}
            onChange={handleSearch}
            InputProps={{
              startAdornment: <SearchIcon color="action" />,
            }}
            sx={{ mr: 2 }}
          />
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => setIsAddModalOpen(true)}
          >
            Add Company
          </Button>
        </Box>
      </Box>
      <Box sx={{ flexGrow: 1 }}>
        <DataGrid
          rows={filteredRows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { pageSize: pageSize, page: 0 },
            },
          }}
          pageSizeOptions={[5, 10, 25]}
          disableRowSelectionOnClick
          autoHeight
        />
      </Box>
      <AddCompanyModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddCompany}
      />
      {editingCompany && (
        <EditCompanyModal
          open={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onEdit={handleSaveEdit}
          company={editingCompany}
        />
      )}
    </Box>
  );
};

export default CompanyTable;
