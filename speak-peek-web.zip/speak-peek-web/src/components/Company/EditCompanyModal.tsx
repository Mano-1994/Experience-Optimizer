import React, { useState, useEffect } from "react";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

interface EditCompanyModalProps {
  open: boolean;
  onClose: () => void;
  onEdit: (company: any) => void;
  company: any;
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const EditCompanyModal: React.FC<EditCompanyModalProps> = ({
  open,
  onClose,
  onEdit,
  company,
}) => {
  const [companyName, setCompanyName] = useState(company.companyName);
  const [organizationId, setOrganizationId] = useState(company.organizationId);
  const [authorizationClient, setAuthorizationClient] = useState(
    company.authorizationClient
  );
  const currentUser = useSelector((state: RootState) => state.user);

  useEffect(() => {
    setCompanyName(company.companyName);
    setOrganizationId(company.organizationId);
    setAuthorizationClient(company.authorizationClient);
  }, [company]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEdit({
      ...company,
      companyName,
      organizationId,
      authorizationClient,
      lastUpdateBy: currentUser.name,
      lastUpdateDate: new Date().toISOString().split("T")[0],
    });
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" component="h2" mb={2}>
          Edit Company
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Company Name"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Organization ID"
            value={organizationId}
            onChange={(e) => setOrganizationId(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Authorization Client"
            value={authorizationClient}
            onChange={(e) => setAuthorizationClient(e.target.value)}
            margin="normal"
            required
          />
          <Box mt={2}>
            <Button type="submit" variant="contained" color="primary">
              Save Changes
            </Button>
            <Button onClick={onClose} variant="outlined" sx={{ ml: 1 }}>
              Cancel
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

export default EditCompanyModal;
