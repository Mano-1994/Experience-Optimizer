import React from "react";
import { Box, Typography, Grid, Paper } from "@mui/material";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Bar, Line, Pie, Line as AreaChart } from "react-chartjs-2";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const Dashboard: React.FC = () => {
  // Dummy data for charts
  const botPerformanceData = [
    { name: "Bot A", success: 85, failure: 15 },
    { name: "Bot B", success: 75, failure: 25 },
    { name: "Bot C", success: 90, failure: 10 },
    { name: "Bot D", success: 70, failure: 30 },
  ];

  const userSatisfactionData = [
    { name: "Jan", satisfaction: 75 },
    { name: "Feb", satisfaction: 80 },
    { name: "Mar", satisfaction: 85 },
    { name: "Apr", satisfaction: 82 },
    { name: "May", satisfaction: 88 },
    { name: "Jun", satisfaction: 90 },
  ];

  const intentMatchData = [
    { name: "Bot A", matches: 750, misses: 150, systemErrors: 100 },
    { name: "Bot B", matches: 620, misses: 180, systemErrors: 80 },
    { name: "Bot C", matches: 880, misses: 90, systemErrors: 30 },
    { name: "Bot D", matches: 550, misses: 220, systemErrors: 130 },
  ];

  const botInteractionTrendData = [
    { name: "Week 1", Text: 400, Voice: 240, Button: 60 },
    { name: "Week 2", Text: 300, Voice: 300, Button: 80 },
    { name: "Week 3", Text: 500, Voice: 350, Button: 70 },
    { name: "Week 4", Text: 450, Voice: 280, Button: 90 },
    { name: "Week 5", Text: 550, Voice: 320, Button: 100 },
  ];

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];

  // Chart configurations
  const botPerformanceOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const botPerformanceChartData = {
    labels: botPerformanceData.map((d) => d.name),
    datasets: [
      {
        label: "Success",
        data: botPerformanceData.map((d) => d.success),
        backgroundColor: "#82ca9d",
      },
      {
        label: "Failure",
        data: botPerformanceData.map((d) => d.failure),
        backgroundColor: "#8884d8",
      },
    ],
  };

  const userSatisfactionChartData = {
    labels: userSatisfactionData.map((d) => d.name),
    datasets: [
      {
        label: "Satisfaction",
        data: userSatisfactionData.map((d) => d.satisfaction),
        borderColor: "#8884d8",
        tension: 0.1,
      },
    ],
  };

  const intentMatchChartData = {
    labels: intentMatchData.map((d) => d.name),
    datasets: [
      {
        label: "Intent Matches",
        data: intentMatchData.map((d) => d.matches),
        backgroundColor: "#4CAF50", // Green for success
      },
      {
        label: "Intent Misses",
        data: intentMatchData.map((d) => d.misses),
        backgroundColor: "#FFC107", // Yellow for misses
      },
      {
        label: "System Errors",
        data: intentMatchData.map((d) => d.systemErrors),
        backgroundColor: "#F44336", // Red for errors
      },
    ],
  };

  const intentMatchOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
      title: {
        display: true,
        text: "Intent Recognition Performance by Bot",
      },
    },
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
        beginAtZero: true,
      },
    },
  };

  const botInteractionTrendChartData = {
    labels: botInteractionTrendData.map((d) => d.name),
    datasets: [
      {
        label: "Bot A",
        data: botInteractionTrendData.map((d) => d.Text),
        borderColor: "#8884d8",
        backgroundColor: "#8884d8",
        fill: true,
      },
      {
        label: "Bot B",
        data: botInteractionTrendData.map((d) => d.Voice),
        borderColor: "#82ca9d",
        backgroundColor: "#82ca9d",
        fill: true,
      },
      {
        label: "Bot C",
        data: botInteractionTrendData.map((d) => d.Button),
        borderColor: "#ffc658",
        backgroundColor: "#ffc658",
        fill: true,
      },
    ],
  };

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Bots Dashboard
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Bot Performance
            </Typography>
            <Bar
              data={botPerformanceChartData}
              options={botPerformanceOptions}
            />
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              User Satisfaction Trend
            </Typography>
            <Line
              data={userSatisfactionChartData}
              options={{ responsive: true }}
            />
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Intent Recognition Performance
            </Typography>
            <Bar data={intentMatchChartData} options={intentMatchOptions} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Bot Interaction Trend
            </Typography>
            <Line
              data={botInteractionTrendChartData}
              options={{
                responsive: true,
                scales: {
                  y: {
                    stacked: true,
                  },
                  x: {
                    stacked: true,
                  },
                },
              }}
            />
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
