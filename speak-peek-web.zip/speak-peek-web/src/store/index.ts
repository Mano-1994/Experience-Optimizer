import { configureStore, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { currentUser } from "../utils/tempData";

interface UserState {
  name: string;
  email: string;
}

const userSlice = createSlice({
  name: "user",
  initialState: currentUser as UserState,
  reducers: {
    setUser: (
      state: { name: any; email: any },
      action: PayloadAction<UserState>
    ) => {
      state.name = action.payload.name;
      state.email = action.payload.email;
    },
  },
});

export const { setUser } = userSlice.actions;

export const store = configureStore({
  reducer: {
    user: userSlice.reducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
