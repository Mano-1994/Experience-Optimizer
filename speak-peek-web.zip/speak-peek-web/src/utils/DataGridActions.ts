export function handleEdit(id: number): void {
  console.log(`Edit company with id: ${id}`);
}

export function handleDelete(id: number): void {
  console.log(`Delete company with id: ${id}`);
}
